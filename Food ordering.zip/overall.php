<?php include("head.html")
?>
<?php include("foot.html")
?>
