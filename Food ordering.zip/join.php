<?php include("head.html")
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style>
.ho{
background-color:#99CCFF;
height:610px;
width:1000px;
margin-left:auto;
margin-right:auto;
}
.design img{
display:block;
margin-left:auto;
margin-right:auto;
}
.design{
text-align:center;
position:relative;
top:30px;
}
.title{
color:#FFFFFF;
font-family:"Bahnschrift Light";
height:40px;
width:1000px;
color:#FF3333;
text-align:center;
position:relative;
top:40px;
}
.content{
color:#FFFFFF;
font-size:20px;
width:1000px;
margin-left:auto;
margin-right:auto;
text-align:center;
position:relative;
top:25px;
}
</style>
<body>
<div class="ho">
<div class="design">
<img src="woman-eating-brownie-5625b5a.jpg" height="400px" width="570px"/>
</div>
<div class="title">
<h2>Quick Bytes</h2>
</div>
<div class="content">
<p>Remember the joy of biting into a freshly baked cookie,still warm, with melted chocolate oozing inside?<br>
The tangy-spicy kick of pani puri that makes you close your eyes and savor every bite! Appetizing right?<br>
Visit our shop !!</p> 
</div>
</div>
</body>
</head>
</html>
<?php include("foot.html")
?>
