<?php include("head.html")
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<style>
.register {
width: 1000px;
margin-left: auto;
margin-right: auto;
border-radius:14px;
height: 970px;
background-color: rgba(255, 255, 255, 0.9);
box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
padding: 20px;
}

.cont {
position: relative;
left: 300px;
font-family: "Baskerville Old Face";
top: 80px;
}

.cus {
font-size: 25px;
font-family: Bell MT;
position: relative;
left: 340px;
top: 40px;
}

.register label {
margin-bottom: 5px;
}

.register input[type="text"],
.register input[type="password"],
.register textarea {
padding: 10px;
border: 1px solid #ccc;
border-radius: 5px;
margin-bottom: 15px;
font-size: 14px;
}

.register input[type="radio"] {
margin-right: 5px;
}

.register input[type="submit"],
.register input[type="reset"] {
padding: 10px 15px;
border: none;
border-radius: 5px;
cursor: pointer;
font-size: 16px;
}

.register input[type="submit"] {
background-color: #4CAF50;
color: #fff;
margin-right: 10px;
}

.register input[type="submit"]:hover {
background-color: #45a049;
}

.register input[type="reset"] {
background-color: #CC3333;
color: #fff;
}

.register input[type="reset"]:hover {
background-color: #d32f2f;
}

.register h2 {
text-align: center;
margin-bottom: 20px;
color: #333;
}


</style>
<body>
<div class="register">
<span class="cus"><strong>CUSTOMER DETAILS</strong></span>
<div class="cont">
<form action="connect.php" method="post">
<label for="fn">FIRST NAME:<br></label>
<input type="text" size="50" name="fn" placeholder="Enter your name" required /><br><br>
<label for="ln">LAST NAME:<br></label>
<input type="text" size="50" name="ln" placeholder="Enter your name" required /><br><br>
<label for="a">AGE:<br></label>
<input type="number" size="3" name="a" required/><br><br>
<label for="d">DOB:<br></label>
<input type="date"  name="d"/><br><br>
<label for="g">GENDER:<br></label>
<input type="radio" value="Male" name="g"/>Male
<input type="radio" value="Female" name="g"/>Female
<input type="radio" value="Others" name="g"/>Others
<br><br>
<label for="ph">MOBILE NUMBER:<br></label>
<input type="number" size="50" name="ph"/><br><br>
<label for="e">EMAIL:<br></label>
<input type="varchar" size="50" name="e"/><br><br>
<label for="np">PASSWORD:<br></label>
<input type="password" maxlength="8" min="5" size="50" name="np"/><br><br>
<label for="cp">CONFIRM PASSWORD:<br></label>
<input type="password" size="50" name="cp"/><br><br>
<label for="de">DELIVERY ADDRESS:<br></label>
<input type="text" size="50" name="de"/><br><br>

<input type="submit" value="SUBMIT"/>
<input type="reset" value="CANCEL"/>
</form>
</div>
</div>
</body>
</html>
<?php include("foot.html")
?>