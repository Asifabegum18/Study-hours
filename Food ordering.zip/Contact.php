<?php include("head.html")
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
.top{
margin-left:auto;
margin-right:auto;
width:1000px;
height:770px;
background-color:#F8BBd0;
}
.loc{
position:relative;
left:220px;
top:60px;
}
.tit{
font-size:20px;
position:relative;
left:330px;
top:90px;
color:#FFFFFF;
}
.cont{
font-family:"Italic";
position:relative;
font-size:14px;
top:20px;
left:35px;
}
.tit a{
text-decoration:none;
}
.me{
height:100px;
width:1000px;
}
.me ul li{
position:relative;
top:110px;
left:40px;
font-size:22px;
display:inline;
font-family:"Berlin Sans FB";
padding:60px;
color:#990033;
padding-bottom:60px;
overflow:hidden;
}
.me ul li a{
text-decoration:none;
}
*{
margin:0;
box-sizing:border-box;
}
.tit {
    flex: 1 1 30%;
    max-width: 400px;
    background-color:#CC99FF; /* White background for details */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
</style>
<body>
<div class="top">
<span class="cont"><h2>For Further details:</h2></span>
<div class="loc">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1004336.104626154!2d78.6838192!3d10.4858484!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b0079a735eb5823%3A0x6d660c0da3c628f!2sswiggy%20Office!5e0!3m2!1sen!2sin!4v1739286023809!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<div class="tit">
<address>
Contact us:<br>
<i class="fa fa-address-book"></i>45A, Lake Street,New York<br>
<a href="mailto:smartserve@gmail.com"><i class="fa fa-envelope"></i>Email: smartserve@gmail.com</a><br>
<a href="tel:1234567890"><i class="fa fa-phone"></i>Phone:1234567890</a>
</address>
</div>
<div class="me">
<ul>
<li><i class="fa fa-whatsapp"></i>123467890</li>
<li><i class="fa fa-instagram"></i>smart_serve</li>
<li><i class="fa fa-twitter"></i>smart_serve</li>
</ul>
</div>
</div>
</body>
</html>
<?php include("foot.html")
?>