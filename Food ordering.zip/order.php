<?php include("head.html")
?>
<html>
<head>
</head>
<style>
.over{
width:1000px;
height:1190px;
margin-left:auto;
margin-right:auto;
position:relative;
bottom:22px;
min-height:880px;
}
main {
text-align: center;
padding: 20px;
height:2010px;
width:1000px;
margin-left:auto;
margin-right:auto;
display:inline;
}
.b1{
background-color:#FF6600;
margin-left:auto;
margin-right:auto;   
height:90px;
width:1000px;
}
.con{
color:black;
font-family:"Berlin Sans FB";
text-align:center;
position:relative;
top:25px;
}
.me{
display:flex;
justify-content: center;
gap:20px;
flex-wrap: wrap;
margin-left:auto;
margin-right:auto;
}
.me2{
display:flex;
justify-content: center;
gap:20px;
flex-wrap: wrap;
margin-left:auto;
margin-right:auto;
position:relative;
top:20px;
}
.me3{
display:flex;
justify-content: center;
gap:20px;
flex-wrap: wrap;
margin-left:auto;
margin-right:auto;
position:relative;
top:2px;
}
.tit{
font-size:24px;
font-family:gabriola;
text-align:center;
}
.food-item {
background: white;
padding: 15px;
border-radius: 8px;
box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
width: 250px;
text-align: center;
position:relative;
	
}

.food-item img {
border-radius: 8px;
}

.food-item h3 {
margin: 10px 0;
}

.food-item button {
background-color: #ff6600;
color: white;
border: none;
padding: 10px;
cursor: pointer;
border-radius: 5px;
}

.food-item button:hover {
background-color: #e65c00;
}
.search-container {
display: inline-block;
border: 2px solid #008CBA;
border-radius: 25px;
padding: 5px;
background: white;
position:relative;
bottom:20px;
left:380px;
}
.search-container input {
border: none;
padding: 8px;
width: 200px;
font-size: 16px;
}
.search-container button {
background: #008CBA;
border: none;
padding: 8px 12px;
border-radius: 15px;
cursor: pointer;
color: white;
font-size: 16px;
}
.search-container button:hover {
background: #005f73;
}

</style>

<body>
<div class="over">
<div class="b1">
<span class="con"><h1>FOOD DELIVERY</h1></span>
</div>
<div class="main">
<div class="tit"><h2>Order Your Favorite Food</h2></div>
<div class="search-container">
<input type="text" placeholder="Search...">
<button>??</button>
</div>
<div class="me">
<div class="food-item">
<img src="header-burger-1071x675.jpg" height="150px" width="250px"  alt="Burger">
<h3>Cheese Burger</h3>
<p>$5.99</p>
<button id="orderButton">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButton").addEventListener("click", function() {
        addToCart('Cheese burger');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>

<div class="food-item">
<img src="images33.jpg" height="150px" width="250px"  alt="Pizza">
<h3>Margherita Pizza</h3>
<p>$8.99</p>
<button id="orderButto">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButto").addEventListener("click", function() {
        addToCart('Margherita Pizza');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="food-item">
<img src="Chocolate-Swiss-Roll-4.jpg" height="150px" width="230px"  alt="Swiss Roll">
<h3>Swiss Roll</h3>
<p>$8.65</p>
<button id="orderButtn">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButtn").addEventListener("click", function() {
        addToCart('Swiss Roll');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
</div>
<div class="me2">
<div class="food-item">
<img src="images (1).jpg" height="150px" width="220px" alt="Pasta">
<h3>Italian Pasta</h3>
<p>$6.49</p>
<button id="orderButon">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButon").addEventListener("click", function() {
        addToCart('Italian Pasta');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="food-item">
<img src="images (2).jpg" height="150px" width="230px" alt="Pasta">
<h3>Donuts</h3>
<p>$5</p>
<button id="orderBtton">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderBtton").addEventListener("click", function() {
        addToCart('Donuts');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="food-item">
<img src="download.jpg" height="150px" width="250px"  alt="Pasta">
<h3>Tacos Burittos</h3>
<p>$15.49</p>
<button id="orderButton0">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButton0").addEventListener("click", function() {
        addToCart('Tacos Burittos');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="me3"> 
<div class="food-item">
<img src="download (8).jpg" height="150px" width="230px" alt="Pasta">
<h3>Shakes</h3>
<p>$7.80</p>
<button id="orderButton1">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButton1").addEventListener("click", function() {
        addToCart('Shakes');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="food-item">
<img src="images (5).jpg" height="150px" width="230px" alt="Pasta">
<h3>French Fries</h3>
<p>$11.11</p>
<button id="orderButton2">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButton2").addEventListener("click", function() {
        addToCart('French Fries');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
<div class="food-item">
<img src="download (9).jpg" height="150px" width="230px" alt="Pasta">
<h3>Nuggets</h3>
<p>$14</p>
<button id="orderButton3">Add To Cart</button>

<!-- JavaScript to show the alert message -->
<script type="text/javascript">
    // Adding event listener for compatibility
    document.getElementById("orderButton3").addEventListener("click", function() {
        addToCart('Nuggets');
    });

    function addToCart(item) {
        // Using traditional string concatenation for better compatibility
        alert("You have ordered " + item + "! Thank you!");
    }
</script>

</div>
</div>
</div>
</div>
</div>
</body>
</html>
<?php include("foot.html")
?>