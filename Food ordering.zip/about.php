<?php include("head.html")
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<style>
.image{
height:600px;
width:1000px;
background-color:#333333;
margin-left:auto;
margin-right:auto;
}

.img1{
float:left;

}
.img2{
float:left;
}
.img3{
float:right;

}
.img4{
float:left;
}
.img5{
float:left;
}
.img6{
float:right;

}
</style>
<body>
<div class="image">
<div class="img1">
<marquee direction="up" onmouseover="this.stop()" onmouseout="this.start()">
<img src="download (4).jpg" height="300px" width="330px" />
</marquee>
</div>
<div class="img2">
<marquee direction="up" onmouseover="this.stop()" onmouseout="this.start()">
<img src="images3.jpg" height="300px" width="340px" />
</marquee>
</div>
<div class="img3">
<marquee direction="up" onmouseover="this.stop()" onmouseout="this.start()">
<img src="download (3).jpg" height="300px" width="330px" />
</marquee>
</div>

<div class="img4">
<marquee direction="down" onmouseover="this.stop()" onmouseout="this.start()">
<img src="download (7).jpg" height="300px" width="330px" />
</marquee>
</div>
<div class="img5">
<marquee direction="down" onmouseover="this.stop()" onmouseout="this.start()">
<img src="header-burger-1071x675.jpg" height="300px" width="340px" />
</marquee>
</div>
<div class="img6">
<marquee direction="down" onmouseover="this.stop()" onmouseout="this.start()">
<img src="download (2).jpg" height="300px" width="330px" />
</marquee>
</div>
</div>
</body>
</html>
<?php include("foot.html")
?>
