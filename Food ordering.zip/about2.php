<?php include("head.html")
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<title>Untitled Document</title>
</head>


<style>
.ab{
height:230px;
width:1000px;
margin-left:auto;
margin-right:auto;
}
.cont{
color:#669999;
font-size:32px;
text-align:center;
position:relative;
top:20px;
font-family:"Times New Roman", Times, serif;
left:380px;
}
.c1{
font-size:20px;

text-align:center;
position:relative;
top:40px;
color:#660099;
}
.carousel{
max-height:800px;
margin:auto;
margin-left:auto;
margin-right:auto;
max-width:1000px;
}

.carousel-control-prev-icon, .carousel-control-next-icon{
background-color:black;
color:#000000;
border-radius:50%;
}
</style>
</head>
<body>
<div class="ab">
<span class="cont"><strong>WELCOME!!!</strong></span>
<div class="c1">
<p><strong><em>We are on a mission to redefine the way you experience food. Whether you are craving for a hearty meal, a quick snack or your fav dessert, we're here to bring the best flavors right to your doorstep. We connect you with a wide range of restaurants, cafes and cloud kitchen,offering a variety of cuisines to suit every palate.<em></strong></p>
</div>
</div>
<div id="carouselExample" class="carousel slide" data-bs-ride="carousel"><div class="carousel-inner">
<div class="carousel-item active">
<img src="reviews-feedback-food-delivery.jpg" class="d-block w-100" alt="Slide 1">
</div>
<div class="carousel-item">
<img src="1721279954-features-of-on-demand-delivery-apps.jpg" class="d-block w-100" alt="Slide 3">
</div>
<div class="carousel-item">
<img src="food-delivery-man-with-scooter-holding-fast-food-box-on-mobile-phone-background-fast-food-delivery-service-in-cartoon-design-concept-illustration-vector.jpg" class="d-block w-100" alt="Slide 2">
</div>
<div class="carousel-item">
<img src="Special-combo-meals-discount-poster-vector.jpg" class="d-block w-100" alt="Slide 3">
</div>
<div class="carousel-item">
<img src="WhatsApp Image 2025-02-20 at 8.37.29 PM.jpeg" class="d-block w-100" alt="Slide 2">
</div>
</div>
<button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="visually-hidden">Previous</span>
</button>
<button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="visually-hidden">Next</span>
</button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
 </body>
</html>
