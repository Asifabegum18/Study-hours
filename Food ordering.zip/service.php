<?php include("head.html")
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<style>
.tab{
margin-left:auto;
margin-right:auto;
height:850px;
width:1000px;
position:relative;
background-color:#CCCC99;
}
table{
width:800px;
border-collapse:collapse;
position:relative;
left:80px;
top:40px;
}
.title{
font-family:"Berlin Sans FB";
color:#333399;
position:relative;
top:20px;
left:370px;
}
th{
font-family:"Times New Roman", Times, serif;
}
.table,td,th{
border:2px solid black;
padding:8px;
text-align:center;
font-size:22px;
}
.oddrow{
background-color:#CCCCFF;
}
.evenrow{
background-color:#99CCFF;
}
td:hover{
color:red;
cursor:pointer;
}
*{
margin:0;
box-sizing:border-box;
}
</style>	
<body>
<div class="tab">
<div class="title">
<h2>CUSTOMER'S CART</h2>
</div>
<table border="2" style="width=800 height=900 cell padding=8 cellspacing=0 font-size:18px">
<tr style="background-color:#FFFFFF">
<th>S.No</th>
<th>Name</th>
<th>Order Id</th>
<th>Food Item</th>
<th>Quantity</th>
<th>Price</th>
<th>Location</th>
<th>Order Status</th>
<th>Payment Mode</th>
</tr>
<tr style="font-size:20px" class="oddrow">
<td>1</td>
<td>Alex</td>
<td>101</td>
<td>Burger</td>
<td>2</td>
<td>$30</td>
<td>Los Angeles</td>
<td>Delivered</td>
<td >COD</td>
</tr>
<tr style="font-size:20px"  class="evenrow">
<td>2</td>
<td>Sam</td>
<td>102</td>
<td>Pasta</td>
<td>1</td>
<td>$25.65</td>
<td>New Jersey</td>
<td>Preparing</td>
<td>Credit Card</td>
</tr>
<tr style="font-size:20px"  class="oddrow">
<td>3</td>
<td>Sofi</td>
<td>103</td>
<td>BlueBerry Cake</td>
<td>1.5Kg</td>
<td>$55</td>
<td>California</td>
<td>On the way</td>
<td>Apple Pay</td>
</tr>
<tr style="font-size:20px" class="evenrow">
<td>4</td>
<td>Max</td>
<td>104</td>
<td>Sandwich</td>
<td>1</td>
<td>$49</td>
<td>Texas</td>
<td>Preparing</td>
<td>GPay</td>
</tr>
<tr style="font-size:20px"  class="oddrow">
<td>5</td>
<td>Sarah</td>
<td>105</td>
<td>Fried Chicken</td>
<td>3</td>
<td>$75</td>
<td>New York</td>
<td>Delivered</td>
<td>COD</td>
</tr>
<tr style="font-size:20px" class="evenrow">
<td>6</td>
<td>Ryan</td>
<td>106</td>
<td>Combo Large</td>
<td>1</td>
<td>$58</td>
<td>Texas</td>
<td>On the way</td>
<td>Credit Card</td>
</tr>
<tr style="font-size:20px"  class="oddrow">
<td>7</td>
<td>Michael</td>
<td>107</td>
<td>Dessert Special</td>
<td>2</td>
<td>$65</td>
<td>Los Angeles</td>
<td>Preparing</td>
<td>Credit Card</td>
</tr>
<tr style="font-size:20px" class="evenrow">
<td>8</td>
<td>Nusra</td>
<td>108</td>
<td>Fresh Juice</td>
<td>4</td>
<td>$35.7</td>
<td>New Jersey</td>
<td>Delivered</td>
<td>Apple Pay</td>
</tr>
<tr style="font-size:20px"  class="oddrow">
<td>9</td>
<td>John</td>
<td>109</td>
<td>BBQ</td>
<td>2</td>
<td>$68</td>
<td>California</td>
<td>On the way</td>
<td>COD</td>
</tr>
<tr style="font-size:20px" class="evenrow">
<td>10</td>
<td>Nvidia</td>
<td>110</td>
<td>Pav Bhaji</td>
<td>3</td>
<td>$39</td>
<td>Washington</td>
<td>Preparing</td>
<td>Credit Card</td>
</tr>
</table>
</div>
</div>
</body>
</html>
<?php include("foot.html")
?>