<?php
$a=$_POST["fn"];
$b=$_POST["ln"];
$c=$_POST["a"];
$d=$_POST["d"];
$j=$_POST["g"];
$e=$_POST["ph"];
$f=$_POST["e"];
$g=$_POST["np"];
$h=$_POST["cp"];
$i=$_POST["de"];

$con=mysql_connect("localhost","root","");
mysql_select_db("rc");
mysql_query("insert into registration(fn,ln,a,d,g,ph,e,np,cp,de) values('$a','$b','$c','$d','$j','$e','$f','$g','$h','$i')");
echo("Registration is Successful!!!");
include("register.php");
mysql_close($con);
?>

